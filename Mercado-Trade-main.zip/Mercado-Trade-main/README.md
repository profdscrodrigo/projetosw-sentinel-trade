# SentinelTrade — Plataforma de Trade Financeiro de Alta Criticidade

O **SentinelTrade** é a especificação e a modelagem de uma plataforma de negociação distribuída, segura, escalável e tolerante a falhas, voltada ao mercado de capitais simulado (ações, ETFs e fundos imobiliários) da corretora fictícia **Orion Capital**.

Por se tratar de um sistema financeiro de **alta criticidade**, a modelagem prioriza segurança, rastreabilidade das ordens, controle de risco, auditoria imutável e resiliência (timeout, retentativa, idempotência, fila de mensagens e modo de indisponibilidade segura).

Projeto integrador da disciplina **Projeto de Software**, da **Universidade Presbiteriana Mackenzie** (Faculdade de Computação e Informática — FCI).

---

## Integrantes

| Nome | TIA | GitHub |
|---|---|---|
| Miguel Bastos Dias Barbosa | 10736603 | [@SpookyBR](https://github.com/SpookyBR) |
| Arthur Candido Palma | 10743580 | [@arthurcpalm0](https://github.com/arthurcpalm0) |
| Kauê Cordeiro Abreu | 10741435 | [@kaue-byte](https://github.com/kaue-byte) |

---

## Status do projeto

Esta entrega é de **especificação e modelagem**. O repositório contém documentação e diagramas, **sem código executável**. Não há aplicação para compilar ou rodar; as instruções abaixo explicam como acessar e navegar o material.

---

## Entregáveis

| # | Entregável | Onde está |
|---|---|---|
| 1 | Repositório Git (README, `.gitignore`, `.env.example`, pasta `docs/`) | Este repositório |
| 2 | Engenharia de requisitos | [`docs/requisitos/Sentinel_Trade_Requisitos.pdf`](docs/requisitos/Sentinel_Trade_Requisitos.pdf) |
| 3 | UML — diagrama de casos de uso | [`docs/diagramas/SentinelTrade-Casos-de-Uso.png`](docs/diagramas/SentinelTrade-Casos-de-Uso.png) |

O documento de requisitos contém: visão e objetivo, atores, requisitos funcionais e não funcionais, regras de negócio, restrições técnicas, critérios de aceitação e matriz de rastreabilidade (requisito, diagrama, implementação e teste), além de anexos com o ciclo de vida da ordem e os casos de teste previstos.

---

## Escopo do sistema

O SentinelTrade deve:

- autenticar usuários com MFA;
- manter investidores, contas, carteiras, ativos e limites financeiros;
- receber cotações em tempo quase real de um provedor externo;
- permitir ordens de compra, venda, cancelamento e consulta;
- validar saldo, posição em carteira, limite de risco e situação do mercado antes de transmitir a ordem;
- integrar-se a uma Bolsa/Corretora **simulada** (sem dinheiro ou bolsa reais);
- acompanhar o ciclo de vida das ordens;
- registrar logs de auditoria imutáveis;
- notificar o investidor sobre execução, rejeição, cancelamento ou falha;
- operar com recuperação de falhas, indisponibilidade controlada e prevenção de ordens duplicadas.

---

## Tecnologias e ferramentas

| Finalidade | Ferramenta |
|---|---|
| Versionamento | Git e GitHub |
| Modelagem UML (casos de uso) | draw.io (diagrams.net) e Python (Matplotlib) |
| Documentação | Markdown e PDF (documento de requisitos) |

A linguagem de programação e as demais tecnologias de implementação serão definidas na fase de implementação (ver restrição técnica RT08 no documento de requisitos).

---

## Diagrama de casos de uso

![Diagrama de casos de uso do SentinelTrade](docs/diagramas/SentinelTrade-Casos-de-Uso.png)

---

## Estrutura do repositório

```
Mercado-Trade/
├── README.md
├── .gitignore
├── .env.example
└── docs/
    ├── enunciado/     # PDF com o enunciado do professor
    ├── diagramas/     # UML: casos de uso
    ├── requisitos/    # Engenharia de requisitos
    └── evidencias/    # Evidências de desenvolvimento
```

---

## Como acessar e navegar

### Pré-requisitos

- [Git](https://git-scm.com) instalado.
- Acesso ao repositório (ele é **privado**; é necessário ser colaborador).
- Qualquer leitor de Markdown, PDF e imagens (o próprio GitHub renderiza todos).

### Passo a passo

1. **Clone o repositório:**
   ```bash
   git clone https://github.com/SpookyBR/Mercado-Trade.git
   cd Mercado-Trade
   ```

2. **Leia a documentação nesta ordem:**
   1. `docs/enunciado/` — o que foi pedido.
   2. `docs/diagramas/` — diagrama de casos de uso.
   3. `docs/requisitos/` — documento de engenharia de requisitos.
   4. `docs/evidencias/` — evidências do processo.

3. **Variáveis de ambiente:** o arquivo `.env.example` está presente e propositalmente vazio, servindo de modelo para o `.env` local. Nunca crie um `.env` com valores reais dentro do repositório.

---

## Segurança do repositório

- Nenhuma senha, token, chave de API ou dado sensível deve ser versionado.
- O arquivo `.env` está listado no `.gitignore`.
- O `.env.example` é versionado e mantido vazio, sem valores.